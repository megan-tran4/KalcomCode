//
//  patientDemoApp.swift
//  patientDemo
//
//  Created by admin on 10/25/23.
//

import SwiftUI

@main
struct patientDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
