//
//  requestRecieved.swift
//  patientDemo
//
//  Created by admin on 10/25/23.
//

import SwiftUI

struct requestRecieved: View {
    var body: some View {
        VStack {
            Image("blue checkmark")
                .resizable()
                .frame(width: 300, height: 300)
                .padding(20)
            Text("Request Sent")
                .font(.title)
                .scaleEffect(1.5)
                .bold()
                .padding(20)
            NavigationLink(destination: ContentView()){
                ZStack {
                    RoundedRectangle(cornerRadius: 5)
                        .frame(width: 250, height: 75)
                        .foregroundColor(Color(red:74/255, green:154/255, blue:212/255))
                    Text("Return")
                        .font(.title)
                        .bold()
                        .foregroundColor(.white)
                }
            }
            .padding(20)
        }
    }
}

#Preview {
    requestRecieved()
}
