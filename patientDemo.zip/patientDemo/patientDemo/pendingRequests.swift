//
//  pendingRequests.swift
//  patientDemo
//
//  Created by admin on 10/26/23.
//

import SwiftUI

struct pendingRequests: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    pendingRequests()
}
